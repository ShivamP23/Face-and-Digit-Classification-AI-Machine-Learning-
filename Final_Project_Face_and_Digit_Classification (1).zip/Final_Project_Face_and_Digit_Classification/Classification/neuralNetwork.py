import numpy as np
import scipy.optimize as opt
import time

#authors: harsh_patel, shivam_patel

def featuresExtract(datum,type):
    """
    Extract features from a datum based on the specified type.

    :param datum: Input datum.
    :param type: Type of feature extraction (0 for basic, 1 for advanced).
    :return: Extracted features.
    """
    if type==0:
        return basicFeaturesExtract(datum)
    else:
        return advancedFeaturesExtract(datum)

def batchExtract(data,type):
    """
    Extract features from a batch of data based on the specified type.

    :param data: Input data batch.
    :param type: Type of feature extraction (0 for basic, 1 for advanced).
    :return: Extracted features.
    """
    if type==0:
        return basicBatchExtract(data)
    else:
        return advancedBatchExtract(data)

def basicFeaturesExtract(datum):
    """
    Basic feature extraction from a datum.

    :param datum: Input datum.
    :return: Extracted features.
    """
    features = []
    for x in range(datum.height):
        row = []
        for y in range(datum.width):
            if datum.getPixel(x, y) > 0:
                row.append(1)
            else:
                row.append(0)
        features.append(row)
    return np.array(features)

def isValid(s,w,h):
    """
    Check if a pixel coordinate is valid within image boundaries.

    :param s: Pixel coordinate (x, y).
    :param w: Image width.
    :param h: Image height.
    :return: True if valid, False otherwise.
    """
    #distinguish whether out of boundary
    x,y=s
    return (x>=0 and y>=0 and x<h and y<w)

def getNeighbor(s,w,h,visited):
    """
    Get valid neighbors of a pixel coordinate.

    :param s: Pixel coordinate (x, y).
    :param w: Image width.
    :param h: Image height.
    :param visited: Visited pixel matrix.
    :return: List of valid neighbors.
    """
    x,y=s
    neighbors=[]
    if isValid((x-1,y),w,h) and not visited[x-1][y]:
        neighbors.append((x-1,y))
    if isValid((x+1,y),w,h) and not visited[x+1][y]:
        neighbors.append((x+1,y))
    if isValid((x,y-1),w,h) and not visited[x][y-1]:
        neighbors.append((x,y-1))
    if isValid((x,y+1),w,h) and not visited[x][y+1]:
        neighbors.append((x,y+1))
    return neighbors

def advancedFeaturesExtract(datum):
    """
    Advanced feature extraction using cycle detection.

    :param datum: Input datum.
    :return: Extracted features.
    """
    #find cycles in the image using DFS
    width=datum.width
    height=datum.height
    #cycle cnt
    cycle=-1
    features = basicFeaturesExtract(datum)
    #visited->1;not->0
    visited=np.empty_like((height,width))
    visited=np.array(features)
    while not (np.count_nonzero(visited)==visited.size):
        open=[]
        #get next 0
        open.append(np.unravel_index(visited.argmin(),visited.shape))
        while not (len(open)==0) :
            current=open.pop()
            visited[current[0]][current[1]]=1
            neighbors=getNeighbor(current,width,height,visited)
            for nb in neighbors:
                if not features[nb[0]][nb[1]]:
                    open.append(nb)
        cycle+=1
    cyclef=np.zeros((1,width))
    for i in range(cycle):
        cyclef[0][i]=1
    features=np.vstack((features,cyclef))
    return features


def basicBatchExtract(data):
    """
    Basic feature extraction for a batch of data.

    :param data: Input data batch.
    :return: Extracted features.
    """
    features = np.empty((len(data), data[0].width * data[0].height))
    for i in range(len(data)):
        feature = np.array(basicFeaturesExtract(data[i])).flatten()
        features[i, :] = feature
    return features.transpose()


def advancedBatchExtract(data):
    """
    Advanced feature extraction for a batch of data.

    :param data: Input data batch.
    :return: Extracted features.
    """
    features = np.empty((len(data), data[0].width * (data[0].height+1)))
    for i in range(len(data)):
        feature = np.array(advancedFeaturesExtract(data[i])).flatten()
        features[i, :] = feature
    return features.transpose()

"""This is the activation function"""
def sigmoid(x):
    """
    Sigmoid activation function.

    :param x: Input value.
    :return: Sigmoid result.
    """
    return 1.0 / (1.0 + np.exp(-x))


def dsigmoid(y):
    """
    derivative of sigmoid
    in this function y is already sigmoided
    """
    return y * (1.0 - y)


class NeuralNetworkClassifier():
    def __init__(self, legalLabels,inputNum, hiddenNum, outputNum, dataNum, l):
        """
        Initialize the neural network classifier.

        :param legalLabels: Legal labels for classification.
        :param inputNum: Number of input neurons.
        :param hiddenNum: Number of hidden neurons.
        :param outputNum: Number of output neurons.
        :param dataNum: Number of data points.
        :param l: Lambda parameter.
        """
        """
        input: the number of input neurons (in this case features)
        hidden: the number of hidden neurons (should be tuned)
        output: the number of output neurons (the classifications of image)
        l: lambda
        """
        self.input = inputNum  # without bias node
        self.hidden = hiddenNum  # without bias node
        self.output = outputNum
        self.dataNum = dataNum
        self.legalLabels = legalLabels
        self.l = l

        # Allocate memory for activation matrix of 1s
        self.inputActivation = np.ones((self.input + 1, dataNum))  # add bias node
        self.hiddenActivation = np.ones((self.hidden + 1, dataNum))  # add bias node
        self.outputActivation = np.ones((self.output, dataNum))

        # Allocate memory for bias vector
        self.bias = np.ones((1, dataNum))

        # Allocate memory for change matrix of 0s
        self.inputChange = np.zeros((self.hidden, self.input + 1))
        self.outputChange = np.zeros((self.output, self.hidden + 1))

        # Calculate epsilon for randomization
        self.hiddenEpsilon = np.sqrt(6.0 / (self.input + self.hidden))
        self.outputEpsilon = np.sqrt(6.0 / (self.input + self.output))

        # Allocate memory for randomized weights
        self.inputWeights = np.random.rand(self.hidden, self.input + 1) * 2 * self.hiddenEpsilon - self.hiddenEpsilon
        self.outputWeights = np.random.rand(self.output, self.hidden + 1) * 2 * self.outputEpsilon - self.outputEpsilon

    def setLambda(self, l):
        "update lambda"
        self.l = l
    def customizeDataNum(self, dataNum):
        """
        Update data number and reinitialize matrices.

        :param dataNum: New number of data points.
        """
        self.dataNum = dataNum
        self.inputActivation = np.ones((self.input + 1, dataNum))  # add bias node
        self.hiddenActivation = np.ones((self.hidden + 1, dataNum))  # add bias node
        self.outputActivation = np.ones((self.output, dataNum))

        "Allocate memory for bias vector"
        self.bias = np.ones((1, dataNum))

        "Allocate memory for change matrix of 0s"
        self.inputChange = np.zeros((self.hidden, self.input + 1))
        self.outputChange = np.zeros((self.output, self.hidden + 1))

        "Calculate epsilon for randomization"
        self.hiddenEpsilon = np.sqrt(6.0 / (self.input + self.hidden))
        self.outputEpsilon = np.sqrt(6.0 / (self.input + self.output))

        "Allocate memory for randomized weights"
        self.inputWeights = np.random.rand(self.hidden, self.input + 1) * 2 * self.hiddenEpsilon - self.hiddenEpsilon
        self.outputWeights = np.random.rand(self.output, self.hidden + 1) * 2 * self.outputEpsilon - self.outputEpsilon
    def feedForward(self, thetaVec):
        """
        Perform feedforward propagation.

        :param thetaVec: Vectorized weights.
        :return: Cost function value.
        """
        "Reshape thetaVec into two weights matrices"
        self.inputWeights = thetaVec[0:self.hidden * (self.input + 1)].reshape((self.hidden, self.input + 1))
        self.outputWeights = thetaVec[-self.output * (self.hidden + 1):].reshape((self.output, self.hidden + 1))

        "Hidden activation"
        hiddenZ = self.inputWeights.dot(self.inputActivation)
        self.hiddenActivation[:-1, :] = sigmoid(hiddenZ)

        "Output activation"
        outputZ = self.outputWeights.dot(self.hiddenActivation)
        self.outputActivation = sigmoid(outputZ)

        "Calculate cost function"
        costMatrix = self.outputTruth * np.log(self.outputActivation) + (1 - self.outputTruth) * np.log(
            1 - self.outputActivation)
        regulations = (np.sum(self.outputWeights[:, :-1] ** 2) + np.sum(self.inputWeights[:, :-1] ** 2)) * self.l / 2
        return (-costMatrix.sum() + regulations) / self.dataNum

    def backPropagate(self, thetaVec):
        """
        Perform backpropagation.

        :param thetaVec: Vectorized weights.
        :return: Vectorized weight changes.
        """
        "Reshape thetaVec into two weights matrices"
        self.inputWeights = thetaVec[0:self.hidden * (self.input + 1)].reshape((self.hidden, self.input + 1))
        self.outputWeights = thetaVec[-self.output * (self.hidden + 1):].reshape((self.output, self.hidden + 1))

        "Calculate lower case delta"
        outputError = self.outputActivation - self.outputTruth
        hiddenError = self.outputWeights[:, :-1].T.dot(outputError) * dsigmoid(self.hiddenActivation[:-1:])

        "Calculate upper case delta"
        self.outputChange = outputError.dot(self.hiddenActivation.T) / self.dataNum
        self.inputChange = hiddenError.dot(self.inputActivation.T) / self.dataNum

        "Add regulations"
        self.outputChange[:, :-1].__add__(self.l * self.outputWeights[:, :-1])
        self.inputChange[:, :-1].__add__(self.l * self.inputWeights[:, :-1])

        return np.append(self.inputChange.ravel(), self.outputChange.ravel())

    def train(self, trainData, trainLabels, validData, validLabels):
        """
        Train the neural network.

        :param trainData: Training data.
        :param trainLabels: Labels for training data.
        :param validData: Validation data.
        :param validLabels: Labels for validation data.
        """
        "Initialization"
        self.trainData = trainData
        self.trainLabels = trainLabels
        self.validaData = validData
        self.validLabels = validLabels

        "Calculate the amount of train data"
        self.size_train = len(list(trainData))
        features_train = []
        for datum in trainData:
            feature = list(datum.values())
            features_train.append(feature)
        train_set = np.array(features_train, np.int32)

        iteration = 100
        # Set input activation for training data
        self.inputActivation[:-1, :] = train_set.transpose()
        # Set output truth labels for training data
        self.outputTruth = self.genTruthMatrix(trainLabels)
        # Propagate
        thetaVec = np.append(self.inputWeights.ravel(), self.outputWeights.ravel())
        thetaVec = opt.fmin_cg(self.feedForward, thetaVec, fprime=self.backPropagate, maxiter=iteration)
        self.inputWeights = thetaVec[0:self.hidden * (self.input + 1)].reshape((self.hidden, self.input + 1))
        self.outputWeights = thetaVec[-self.output * (self.hidden + 1):].reshape((self.output, self.hidden + 1))


    def classify(self, testData):
        """
        Classify test data.

        :param testData: Test data.
        :return: Predicted labels.
        """
        # Set input activation for test data
        "For classify in case the difference of size between trainData and testData "
        self.size_test = len(list(testData))
        features_test = []
        for datum in testData:
            feature = list(datum.values())
            features_test.append(feature)
        test_set = np.array(features_test, np.int32)
        feature_test_set = test_set.transpose()

        if feature_test_set.shape[1] != self.inputActivation.shape[1]:
            self.inputActivation = np.ones((self.input + 1, feature_test_set.shape[1]))
            self.hiddenActivation = np.ones((self.hidden + 1, feature_test_set.shape[1]))
            self.outputActivation = np.ones((self.output + 1, feature_test_set.shape[1]))
        self.inputActivation[:-1, :] = feature_test_set

        "Hidden activation"
        hiddenZ = self.inputWeights.dot(self.inputActivation)
        self.hiddenActivation[:-1, :] = sigmoid(hiddenZ)

        "Output activation"
        outputZ = self.outputWeights.dot(self.hiddenActivation)
        self.outputActivation = sigmoid(outputZ)
        if self.output > 1:
            return np.argmax(self.outputActivation, axis=0).tolist()
        else:
            return (self.outputActivation>0.5).ravel()

    "Checking condition matrix"
    def genTruthMatrix(self, trainLabels):
        """
        Generate truth matrix from training labels.

        :param trainLabels: Training labels.
        :return: Truth matrix.
        """
        truth = np.zeros((self.output, self.dataNum))
        for i in range(self.dataNum):
            label = trainLabels[i]
            if self.output == 1:
                truth[:,i] = label
            else:
                truth[label, i] = 1
        return truth

