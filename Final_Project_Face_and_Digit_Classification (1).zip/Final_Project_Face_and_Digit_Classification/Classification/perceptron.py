# perceptron.py
# -------------
# Licensing Information: Please do not distribute or publish solutions to this
# project. You are free to use and extend these projects for educational
# purposes. The Pacman AI projects were developed at UC Berkeley, primarily by
# John DeNero (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# For more info, see http://inst.eecs.berkeley.edu/~cs188/sp09/pacman.html
# authors: shivam_patel, harsh_patel
# Perceptron implementation
import util
PRINT = True

class PerceptronClassifier:
  """
  Perceptron classifier.
  
  Note that the variable 'datum' in this code refers to a counter of features
  (not to a raw samples.Datum).
  """
  def __init__(self, legalLabels, max_iterations):
    # Initialize Perceptron classifier with legal labels and maximum iterations
    self.legalLabels = legalLabels
    self.type = "perceptron"
    self.max_iterations = max_iterations
    self.weights = {}
    for label in legalLabels:
        # Initialize weights with an additional term for the bias
        self.weights[label] = util.Counter()  # Assume initial bias is zero if not set
        self.weights[label]['bias'] = 0  # Adding a bias key


  def setWeights(self, weights):
    # Set weights for each legal label
    assert len(weights) == len(self.legalLabels)
    self.weights == weights
      
  def train(self, trainingData, trainingLabels, validationData, validationLabels):
    # Train the Perceptron classifier
    for iteration in range(self.max_iterations):
        print("Starting iteration ", iteration, "...")
        # Iterate through training data
        for i in range(len(trainingData)):
            trueLabel = trainingLabels[i]
            datum = trainingData[i]
            scores = util.Counter()
            # Calculate scores for each legal label
            for label in self.legalLabels:
                scores[label] = self.weights[label] * datum  # Dot product
            guess = scores.argMax()
            # Update weights if guess is incorrect
            if guess != trueLabel:
                self.weights[trueLabel] += datum
                self.weights[guess] -= datum

    
  def classify(self, data):
    # Classify input data
    guesses = []
    for datum in data:
        datum['bias'] = 1  # Ensure the bias term is set to 1 for classification
        vectors = util.Counter()
        # Calculate scores for each legal label
        for l in self.legalLabels:
            vectors[l] = self.weights[l] * datum  # Includes bias in the calculation
        guesses.append(vectors.argMax())  # Append the label with maximum score as guess
    return guesses

  def findHighWeightFeatures(self, label):
    # Find features with highest weights for a given label
    featuresWeights = list(self.weights[label].items()) 
    featuresWeights.sort(key=lambda x: x[1], reverse=True) # Sort by weight in descending order
    return featuresWeights[:100] # Return top 100 features with highest weights
